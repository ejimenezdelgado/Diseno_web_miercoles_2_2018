import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { Route } from "@angular/compiler/src/core";

import { RouterModule, Routes } from "@angular/router";
import { MaterialDemoComponent } from "./material/material-demo/material-demo.component";
import { HomeComponent } from "./home/home.component";

import { MarsComponent } from "./mars/mars.component";

const routes: Routes = [
  {
    path: "",
    redirectTo: "home",
    pathMatch: "full"
  },
  {
    path: "material-demo",
    component: MaterialDemoComponent
  },
  {
    path: "home",
    component: HomeComponent
  },
  {
    path: "mars",
    component: MarsComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  declarations: []
})
export class AppRoutingModule {}
