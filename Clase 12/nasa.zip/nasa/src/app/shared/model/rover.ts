export interface Rover {
  id: number;
  name: string;
}
